#include <cv.h>
#include <highgui.h>
#include <cxcore.h>
#include <cvaux.h>
#include <stdlib.h>
#include <stdio.h>
#include "projection.h"


#define MAXPIX 255

const int thresholdImg = 200;

CvRect locateFace(IplImage *img);

int main(int argc, char ** argv)
{
	char* winName = "Temp";
	char* winGray = "Gris";
	char* winGradientX = "Gradient X";
	char* winGradientY = "Gradient Y";
	char* winOriginal = "Originale";
	char* winProjection = "Projection";

	IplImage * imgOriginal = 0;
	IplImage * imgGradientX = 0;
	IplImage * imgGray = 0;
	IplImage * imgProj = 0;
	IplImage * imgProjHorizontal = 0;
	IplImage * imgSmooth = 0;
	IplImage * imgThreshold = 0;

	CProjection projMain;
	CProjection projY;

	CvSize sz;
	
	if (argc > 1)
		imgOriginal = cvLoadImage(argv[1]);
	else
	{
		printf("Usage : faceDetect picture");
		printf("Press a key to continue...");
		cvWaitKey();
		return 0;
	}
	
	// Construction des objets
	sz = cvSize(imgOriginal->width, imgOriginal->height);
	imgGray = cvCreateImage(sz, 8, 1);
	imgGradientX = cvCreateImage(sz, 8, 1);
	imgSmooth = (IplImage*)cvClone(imgGray);
	imgThreshold = (IplImage*)cvClone(imgGray);


	// Convertion de la couleur vers le niveau de gris
	cvCvtColor(imgOriginal, imgGray, CV_RGB2GRAY);
	
	// Lissage de l'image originale
	cvSmooth(imgGray, imgSmooth, CV_GAUSSIAN, 9, 9);

	// Application du Sobel X
	cvSobel(imgSmooth, imgGradientX, 2, 0, 5);

	//////////////////////////////////
	// D�but de la d�tection de la tete
	//////////////////////////////////
	cvThreshold(imgGradientX, imgThreshold, thresholdImg, 255, CV_THRESH_BINARY);

	//projMain.Range = 0;  // �limine le range blanc

	// R�gle des tampons autour des pics
	projMain.Buffer = 0.15;
	projMain.Range = 0.15;
	

	// Cr�ation de la projection verticale
	projMain.CreateVerticalProjection(imgGradientX);

	// Lissage de la projection
	projMain.Smooth(15);

	// D�claration des pics
	peak leftPk;
	peak rightPk;

	leftPk = projMain.MaxPeak;

	// Trouve le deuxi�me pic
	rightPk = projMain.FindNextPeak();

	// Triage des pics
	if (leftPk.Position > rightPk.Position)
	{
		peak tmp = leftPk;
		leftPk = rightPk;
		rightPk = tmp;
	}

	// Tracer du rectangle entre les pics
	cvRectangle(imgOriginal, cvPoint(leftPk.Position, 0), cvPoint(rightPk.Position, imgOriginal->height), CV_RGB(MAXPIX,MAXPIX, MAXPIX));
	
	imgProj = projMain.CreateProjectionImage();

	//////////////////////////////////
	// Fin de la d�tection de la tete
	//////////////////////////////////

	//////////////////////////////////
	// D�but d�tection zone des yeux
	//////////////////////////////////
	// Creation de la projection � partir du gradient en Y
	projY.Buffer = 0.10;
	projY.Range = 0.10;

	projY.CreateHorizontalProjection(imgGradientX);
	projY.Smooth(15);

	imgProjHorizontal = projY.CreateProjectionImage();

	int upperBound;
	int lowerBound;

	upperBound = projY.MaxPeak.Position - (projY.Buffer * imgGradientX->height);
	lowerBound = projY.MaxPeak.Position + (projY.Buffer * imgGradientX->height);

	cvRectangle(imgOriginal, cvPoint(0, upperBound), cvPoint(imgOriginal->width, lowerBound), CV_RGB(255, 255, 255));

	//////////////////////////////////
	// fin d�tection zone des yeux
	//////////////////////////////////

	////////////////////////////
	// Affichage des images
	////////////////////////////
	cvNamedWindow(winGradientX, CV_WINDOW_AUTOSIZE);
	cvShowImage(winGradientX, imgGradientX);

	cvNamedWindow(winGray, CV_WINDOW_AUTOSIZE);
	cvShowImage(winGray, imgGray);

	cvNamedWindow(winName, CV_WINDOW_AUTOSIZE);
	cvShowImage(winName, imgProj);

	cvNamedWindow(winProjection, CV_WINDOW_AUTOSIZE);
	cvShowImage(winProjection, imgProjHorizontal);

	cvNamedWindow(winOriginal, CV_WINDOW_AUTOSIZE);
	cvShowImage(winOriginal, imgOriginal);

	cvWaitKey();

	cvReleaseImage(&imgThreshold);
	cvReleaseImage(&imgSmooth);
	cvReleaseImage(&imgProj);
	cvReleaseImage(&imgProjHorizontal);
	cvReleaseImage(&imgGray);
	cvReleaseImage(&imgGradientX);
	cvReleaseImage(&imgOriginal);
	
	
	return 0;
}