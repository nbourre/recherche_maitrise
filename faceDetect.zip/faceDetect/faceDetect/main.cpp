#include <cv.h>
#include <highgui.h>
#include <cxcore.h>
#include <cvaux.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include "projection.h"


#define MAXPIX 255

const int thresholdImg = 200;
const int projectionSmooth = 15;

CvRect locateFace(IplImage *img);
IplImage * GetROIImage(IplImage *img);
IplImage * GetSubPixByRect(IplImage *img);


int main(int argc, char ** argv)
{
	char* winSobel = "Sobel head";
	char* winTemp = "Temp";
	char* winGray = "Gris";
	char* winGradientX = "Gradient X";
	char* winEyesGradient = "Eyes gradient";
	char* winOriginal = "Originale";
	char* winProjection = "Projection";
	char* winEyesProjection = "Eyes projection";

	IplImage * imgOriginal = 0;
	IplImage * imgGradientX = 0;
	IplImage * imgGray = 0;
	IplImage * imgProj = 0;
	IplImage * imgProjHorizontal = 0;
	IplImage * imgSmooth = 0;
	IplImage * imgThreshold = 0;

	CProjection projMain;
	CProjection projY;

	CvSize sz;

	clock_t start, end;

	start = clock();

	CvRect rectEyeZone;
	
	if (argc > 1)
		imgOriginal = cvLoadImage(argv[1]);
	else
	{
		printf("Usage : faceDetect picture");
		printf("Press a key to continue...");
		cvWaitKey();
		return 0;
	}
	
	// Construction des objets
	sz = cvSize(imgOriginal->width, imgOriginal->height);
	imgGray = cvCreateImage(sz, 8, 1);
	imgGradientX = cvCreateImage(sz, 8, 1);
	imgSmooth = (IplImage*)cvClone(imgGray);
	imgThreshold = (IplImage*)cvClone(imgGray);
	

	// Convertion de la couleur vers le niveau de gris
	cvCvtColor(imgOriginal, imgGray, CV_RGB2GRAY);
	
	// Lissage de l'image originale
	cvSmooth(imgGray, imgSmooth, CV_GAUSSIAN, 9, 9);

	// Application du Sobel X
	cvSobel(imgSmooth, imgGradientX, 2, 0, 5);

	//////////////////////////////////
	// D�but de la d�tection de la tete
	//////////////////////////////////
	cvThreshold(imgGradientX, imgThreshold, thresholdImg, 255, CV_THRESH_BINARY);

	//projMain.Range = 0;  // �limine le range blanc

	// R�gle des tampons autour des pics
	projMain.Buffer = 0.15;
	projMain.Range = 0.15;
	

	// Cr�ation de la projection verticale
	projMain.CreateVerticalProjection(imgGradientX);

	// Lissage de la projection
	projMain.Smooth(projectionSmooth);

	// D�claration des pics
	peak pkLeft;
	peak pkRight;

	pkLeft = projMain.MaxPeak;

	// Trouve le deuxi�me pic
	pkRight = projMain.FindNextPeak();

	// Triage des pics
	if (pkLeft.Position > pkRight.Position)
	{
		peak tmp = pkLeft;
		pkLeft = pkRight;
		pkRight = tmp;
	}

	//// Tracer du rectangle entre les pics
	//cvRectangle(imgOriginal, cvPoint(pkLeft.Position, 0), cvPoint(pkRight.Position, imgOriginal->height), CV_RGB(MAXPIX,MAXPIX, MAXPIX));
	
	imgProj = projMain.CreateProjectionImage();

	//////////////////////////////////
	// Fin de la d�tection de la tete
	//////////////////////////////////



	//////////////////////////////////
	// D�but d�tection zone des yeux
	//////////////////////////////////
	// Creation de la projection � partir du gradient en Y
	projY.Buffer = 0.10;
	projY.Range = 0.10;

	projY.CreateHorizontalProjection(imgGradientX);
	projY.Smooth(projectionSmooth);

	imgProjHorizontal = projY.CreateProjectionImage();

	int upperBound;
	int lowerBound;

	upperBound = (int)(projY.MaxPeak.Position - (projY.Buffer * imgGradientX->height));
	lowerBound = (int)(projY.MaxPeak.Position + (projY.Buffer * imgGradientX->height));

	//cvRectangle(imgOriginal, cvPoint(0, upperBound), cvPoint(imgOriginal->width, lowerBound), CV_RGB(255, 255, 255));

	// Bounding box
	rectEyeZone.x = pkLeft.Position;
	rectEyeZone.y = upperBound;
	rectEyeZone.height = lowerBound - upperBound;
	rectEyeZone.width = pkRight.Position - pkLeft.Position;

	cvRectangle(imgOriginal, cvPoint(rectEyeZone.x, rectEyeZone.y), 
		cvPoint(rectEyeZone.width + rectEyeZone.x, rectEyeZone.height + rectEyeZone.y), CV_RGB(255, 255, 255));
	
	//////////////////////////////////
	// fin d�tection zone des yeux
	//////////////////////////////////

	//////////////////////////////////
	// D�but d�tection des yeux
	//////////////////////////////////
	
	CProjection projEyes;
	IplImage * imgEyes;
	IplImage * imgProjEyes;
	IplImage * imgEyesGrad;

	cvSetImageROI(imgSmooth, rectEyeZone);
	imgEyes = GetROIImage(imgSmooth);
	cvResetImageROI(imgSmooth);

	imgEyesGrad = cvCreateImage(cvGetSize(imgEyes), imgEyes->depth, imgEyes->nChannels);

	cvSobel(imgEyes, imgEyesGrad, 0, 2, 5);

	projEyes.CreateVerticalProjection(imgEyesGrad);
	projEyes.Smooth(projectionSmooth);

	peak leftEye;
	peak rightEye;

	leftEye = projEyes.MaxPeak;
	rightEye = projEyes.FindNextPeak();

	if (leftEye.Position > rightEye.Position)
	{
		peak tmp;
		tmp = leftEye;
		leftEye = rightEye;
		rightEye = tmp;
	}

	int width;
	CvRect roi;
	IplImage * imgTemp;
	CProjection projTemp;

	width = (int)(projEyes.Buffer * imgEyes->width) * 2;

	/////////////////
	// Oeil gauche
	/////////////////
	roi.height = imgEyes->height;
	roi.width = width;
	roi.x = rectEyeZone.x + (leftEye.Position - (width / 2));  // ATTENTION!! La position est par rapport � l'image originale
	roi.y = rectEyeZone.y;

	cvSetImageROI(imgGradientX, roi);
	imgTemp = GetROIImage(imgGradientX);
	cvResetImageROI(imgGradientX);

	projTemp.CreateHorizontalProjection(imgTemp);
	projTemp.Smooth(projectionSmooth);

	CvPoint ptLeftEye;
	ptLeftEye.x = leftEye.Position + rectEyeZone.x;
	ptLeftEye.y = projTemp.MaxPeak.Position + rectEyeZone.y;

	cvCircle(imgOriginal, ptLeftEye, 10, CV_RGB(255, 0, 0));

	/////////////////
	//Oeil droit
	/////////////////

	roi.x = rectEyeZone.x + (rightEye.Position - (width / 2));  // ATTENTION!! La position est par rapport � l'image originale

	cvSetImageROI(imgGradientX, roi);
	imgTemp = GetROIImage(imgGradientX);
	cvResetImageROI(imgGradientX);

	projTemp.CreateHorizontalProjection(imgTemp);
	projTemp.Smooth(projectionSmooth);

	CvPoint ptRightEye;
	ptRightEye.x = rightEye.Position + rectEyeZone.x;
	ptRightEye.y = projTemp.MaxPeak.Position + rectEyeZone.y;

	cvCircle(imgOriginal, ptRightEye, 10, CV_RGB(255, 0, 0));


		
	// Cr�ation de l'image visuelle de la projection
	imgProjEyes = projEyes.CreateProjectionImage();

	//////////////////////////////////
	// fin d�tection zone des yeux
	//////////////////////////////////
	
	end = clock();
	double dif;

	dif = difftime(end, start) / CLOCKS_PER_SEC;

	printf("Temp d'execution : %.4f secondes", dif);

	////////////////////////////
	// Affichage des images
	////////////////////////////

	cvNamedWindow(winGradientX, CV_WINDOW_AUTOSIZE);
	cvShowImage(winGradientX, imgGradientX);

	cvNamedWindow(winSobel, CV_WINDOW_AUTOSIZE);
	cvShowImage(winSobel, imgProj);

	cvNamedWindow(winProjection, CV_WINDOW_AUTOSIZE);
	cvShowImage(winProjection, imgProjHorizontal);

	cvNamedWindow(winEyesGradient, CV_WINDOW_AUTOSIZE);
	cvShowImage(winEyesGradient, imgEyesGrad);	

	cvNamedWindow(winEyesProjection, CV_WINDOW_AUTOSIZE);
	cvShowImage(winEyesProjection, imgProjEyes);	

	cvNamedWindow(winOriginal);
	cvShowImage(winOriginal, imgOriginal);


	cvWaitKey();

	cvReleaseImage(&imgTemp);
	cvReleaseImage(&imgProjEyes);
	cvReleaseImage(&imgEyes);
	cvReleaseImage(&imgThreshold);
	cvReleaseImage(&imgSmooth);
	cvReleaseImage(&imgProj);
	cvReleaseImage(&imgProjHorizontal);
	cvReleaseImage(&imgGray);
	cvReleaseImage(&imgGradientX);
	cvReleaseImage(&imgOriginal);
	
	
	return 0;
}

/// Fonction qui retourne l'image d'un ROI
IplImage * GetROIImage(IplImage * img)
{
	if (img->roi == NULL)
		return img;

	IplImage * imgOut;

	imgOut = cvCreateImage(cvSize(img->roi->width, img->roi->height), img->depth, img->nChannels);
	cvCopy(img, imgOut);

	return imgOut;
}
