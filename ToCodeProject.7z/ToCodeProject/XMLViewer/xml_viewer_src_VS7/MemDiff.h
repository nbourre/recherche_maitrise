// MemDiff.h: interface for the CMemDiff class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(__AFX_MEMDIFF_H__)
#define __AFX_MEMDIFF_H__

#if _MSC_VER > 1000
   #pragma once
#endif // _MSC_VER > 1000


#endif
