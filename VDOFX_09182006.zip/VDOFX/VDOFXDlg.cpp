// VDOFXDlg.cpp : fichier d'impl�mentation
//

#include "stdafx.h"
#include "VDOFX.h"
#include "VDOFXDlg.h"
#include ".\vdofxdlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// bo�te de dialogue CVDOFXDlg
#define TIMER_ID 1
#define NB_FRAME_INIT 200
#define COUNTER_TURN 100000
#define MOVEMENT_THRESHOLD 15
#define MOVEMENT_THRESHOLD_AFTERINIT 50
#define PIXMAX 255


const char *szMainWindow = "Video";
const char *szSampleWindow = "Sample";



CVDOFXDlg::CVDOFXDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CVDOFXDlg::IDD, pParent)
	, m_iValue(0)
	, m_bEnableVale(FALSE)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CVDOFXDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_SLIDERVALUE, m_ValueSlider);
	DDX_Control(pDX, IDC_EDITVALUE, m_txtValue);
	DDX_Text(pDX, IDC_EDITVALUE, m_iValue);
	DDX_Check(pDX, IDC_CHECKVALUE, m_bEnableVale);
}

BEGIN_MESSAGE_MAP(CVDOFXDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_WM_HSCROLL()
	ON_BN_CLICKED(IDC_BTNOPEN, OnBnClickedBtnopen)
	ON_WM_CLOSE()
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTONSHOW, OnBnClickedButtonshow)
	ON_BN_CLICKED(IDC_CHECKVALUE, OnBnClickedCheckvalue)
END_MESSAGE_MAP()


// gestionnaires de messages pour CVDOFXDlg

BOOL CVDOFXDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// D�finir l'ic�ne de cette bo�te de dialogue. L'infrastructure effectue cela automatiquement
	//  lorsque la fen�tre principale de l'application n'est pas une bo�te de dialogue
	SetIcon(m_hIcon, TRUE);			// D�finir une grande ic�ne
	SetIcon(m_hIcon, FALSE);		// D�finir une petite ic�ne

	// TODO : ajoutez ici une initialisation suppl�mentaire
	m_ValueSlider.SetRange(0, 255);
	m_ValueSlider.SetPos(0);
	
	SetTimer(TIMER_ID, 33, NULL);
	bShowVideo = false;

	lCounter = 0;
	lCounterMultiplier = 0;




	return TRUE;  // retourne TRUE, sauf si vous avez d�fini le focus sur un contr�le
}

// Si vous ajoutez un bouton R�duire � votre bo�te de dialogue, vous devez utiliser le code ci-dessous
//  pour dessiner l'ic�ne. Pour les applications MFC utilisant le mod�le Document/Vue,
//  cela est fait automatiquement par l'infrastructure.

void CVDOFXDlg::OnPaint() 
{
	

	if (IsIconic())
	{
		CPaintDC dc(this); // contexte de p�riph�rique pour la peinture

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Centrer l'ic�ne dans le rectangle client
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Dessiner l'ic�ne
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{

		CDialog::OnPaint();
	}
}

// Le syst�me appelle cette fonction pour obtenir le curseur � afficher lorsque l'utilisateur fait glisser
//  la fen�tre r�duite.
HCURSOR CVDOFXDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CVDOFXDlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	// TODO: Add your message handler code here and/or call default
	m_iValue = m_ValueSlider.GetPos();
	iThreshold = m_iValue;
	
	UpdateData(false);

	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CVDOFXDlg::OnBnClickedBtnopen()
{
	// TODO: Add your control notification handler code here
	if (!OpenFile())
	{
		AfxMessageBox("Could not open file!");
	}
}

bool CVDOFXDlg::OpenFile()
{
	bool bRet = false;
	CString strExtension;

	char * strFilter = {"AVI file (*.avi)|*.avi|JPEG file (*.jpg)|*.jpg|BMP File (*.bmp)|*.bmp|All files (*.*)|*.*||"};

	CFileDialog FileDlg(true, ".avi", NULL, 0, strFilter);

	if (FileDlg.DoModal() == IDOK)
	{
		bRet = true;
		bShowVideo = false;
		strExtension = FileDlg.GetFileExt();

		if (strExtension.MakeLower() == "avi")
		{
			capture = cvCaptureFromFile(FileDlg.GetFileName());
			//capture = cvCaptureFromCAM(-1);
			NbFrames = (int)cvGetCaptureProperty(capture, CV_CAP_PROP_FRAME_COUNT);
			
			iplFrame = cvQueryFrame(capture);

            // Initialize all the necessary image
			iplPrevious = cvCreateImage(cvGetSize(iplFrame), iplFrame->depth, 1);
			iplSub = cvCreateImage(cvGetSize(iplFrame), iplFrame->depth, 1);
			iplTemp = cvCreateImage(cvGetSize(iplFrame), iplFrame->depth, 1);
            iplFrameGray = cvCreateImage(cvGetSize(iplFrame), iplFrame->depth, 1);
            iplGray = cvCreateImage(cvGetSize(iplFrame), iplFrame->depth, 1);

   //         iplPrevious = cvCreateImage(cvGetSize(iplFrame), iplFrame->depth, 1);
			//iplSub = cvCreateImage(cvGetSize(iplFrame), iplFrame->depth, 1);
			//iplTemp = cvCreateImage(cvGetSize(iplFrame), iplFrame->depth, 1);

			cvZero(iplTemp);
			cvCvtColor(iplFrame, iplPrevious, CV_RGB2GRAY);

            blLoaded = true;

                        
			lCounter = 0;
			lCounterMultiplier = 0;
			iHalfHeight = iplFrame->height / 2;
            iNeckHeight = iHalfHeight * 0.8;
			
		}
		else
		{			
			iplFrame = cvLoadImage(FileDlg.GetFileName(), 0);
		}

		if (capture == NULL || iplFrame == NULL)
		{
			bRet = false;
		}
	}
	else
	{
		bRet = false;
	}
	
	
	return bRet;
}

void CVDOFXDlg::OnClose()
{
	// TODO: Add your message handler code here and/or call default
	cvDestroyAllWindows();
    KillTimer(TIMER_ID);

    if (blLoaded)
    {
        cvReleaseImage(&iplGray);
        cvReleaseImage(&iplPrevious);
        cvReleaseImage(&iplSub);
        cvReleaseImage(&iplTemp);
    }

	if (capture != NULL)
		cvReleaseCapture(&capture);

	CDialog::OnClose();
}

void CVDOFXDlg::OnTimer(UINT nIDEvent)
{
	// TODO: Add your message handler code here and/or call default
	if (bShowVideo)
	{

		if (capture != NULL)
		{
			iplFrame = cvQueryFrame(capture);
            cvCvtColor(iplFrame, iplFrameGray, CV_RGB2GRAY);

			
    		
			if (lCounter < NB_FRAME_INIT)
			{
				cvSub(iplFrameGray, iplPrevious, iplSub);
				cvThreshold(iplSub, iplSub, MOVEMENT_THRESHOLD, 255, CV_THRESH_TOZERO);
				cvAdd(iplSub, iplTemp, iplTemp);

                
				cvShowImage(szMainWindow, iplTemp);
			}
            else if (lCounter == NB_FRAME_INIT)
            {
                                
                CvPoint pt1;
                CvPoint pt2;
                CvPoint ptLeft;
                CvPoint ptRight;

                IplImage *iplDest;
                IplConvKernel* element = 0;

                iplDest = cvCreateImage(cvSize(iplTemp->width, iplTemp->height), iplTemp->depth, 1);
                cvZero(iplDest);

                int i;
                int j;
                int iMin;
                int iMax;
                int iValue;


                iMin = 0;
                iMax = iplTemp->width;

                for (j = 0; j < iplTemp->height; j++)
                {                   
                    for (i = 0; i < iplTemp->widthStep; i++)
                    {
                    
                        iValue = (uchar)iplTemp->imageData[j * iplTemp->widthStep + i];

                        if (iValue > MOVEMENT_THRESHOLD_AFTERINIT)
                        {
                            pt1.x = i;
                            pt1.y = j;

                            iplDest->imageData[j * iplDest->widthStep + i] = 255;
                            
                        }
                    }       
                }
                

                // Opening to erase noise
                element = cvCreateStructuringElementEx( 5, 5, 2, 2, CV_SHAPE_RECT, 0 );
                cvErode(iplDest, iplDest, element, 1);
                cvDilate(iplDest, iplDest, element, 1);                
                cvReleaseStructuringElement(&element);

                cvThreshold(iplDest, iplDest, 0, 255, CV_THRESH_BINARY);

               
				
				// Trouvez les coordonn�es de la t�te
				setHeadROI(iplDest, iNeckHeight);				
				_head.rectBox = cvGetImageROI(iplDest);               
                cvShowImage(szSampleWindow, iplDest);
                cvReleaseImage(&iplDest);                
            }
			else
			{
				
				if (m_bEnableVale)
				{
					cvThreshold(iplFrameGray, iplFrameGray, m_iValue, 255, CV_THRESH_BINARY);
				}
                //cvSub(iplFrameGray, iplTemp, iplSub);

				drawMovementBox(iplFrameGray, _head);

				//cvFlip(iplSub);
                cvShowImage(szMainWindow, iplFrameGray);
			}

			cvCopy(iplFrameGray, iplPrevious);


			if (cvGetCaptureProperty(capture, CV_CAP_PROP_POS_FRAMES) >= NbFrames)
			{
				cvSetCaptureProperty(capture, CV_CAP_PROP_POS_FRAMES, 0);  // SetPremierFrame
			}

			lCounter++;

			if (lCounter == COUNTER_TURN)
			{
				lCounterMultiplier++;
				lCounter = 0;
			}
        }

	}


    CDialog::OnTimer(nIDEvent);            
	
    //catch (char *sz)
    //{
    //    bShowVideo = false;
    //    AfxMessageBox(sz);
    //    exit(EXIT_FAILURE);
    //}
}

void CVDOFXDlg::OnBnClickedButtonshow()
{
	if (!bShowVideo)
	{
		
		cvNamedWindow(szMainWindow, CV_WINDOW_AUTOSIZE);
        cvNamedWindow(szSampleWindow, CV_WINDOW_AUTOSIZE);
		//cvCreateTrackbar("Slider", szMainWindow, &iThreshold, 255, CVideoEffectDlg::Threshold); 

        cvShowImage(szSampleWindow, iplFrame);

	}
	else
	{
		cvDestroyWindow(szMainWindow);
	}
	
	bShowVideo = !bShowVideo;
	UpdateData(false);
}

uchar CVDOFXDlg::getPixel( IplImage*img, int lin, int col, int channel ) 
{
    int offset;
    int x;
    int y;

    return ((uchar*)(img->imageData + img->widthStep * lin))[col + channel];
}

void CVDOFXDlg::setHeadROI(IplImage *iplView, int iStartHeight)
{	
	int i;
	int j;
	int iValue;
	int iRight = -1;
	int iLeft = -1;
	int iTop = -1;
	int iBottom = iStartHeight;

	bool bFound = false;

	// Right side
    for (i = 0; i < iplView->widthStep; i++)
    {
		for (j = iStartHeight; j < iplView->height; j++)
	    {
            iValue = (uchar)iplView->imageData[j * iplView->widthStep + i];

			if (iValue > PIXMAX - 10)
			{
                bFound = true;
				iRight = i;
				break;
			}
        }

		if (bFound)
		{
			break;
		}			
    }

	bFound = false;


	// Left Side
	for (i = iplView->widthStep; i > 0 ; i--)
    {
		for (j = iStartHeight; j < iplView->height; j++)
	    {
            iValue = (uchar)iplView->imageData[j * iplView->widthStep + i];

			if (iValue > PIXMAX - 10)
			{				
                bFound = true;
				iLeft = i;
				break;
			}
        }

		if (bFound)
		{
			break;
		}			
    }

	bFound = false;

	// Top side
	for (j = iplView->height - 1; j > iStartHeight ; j--)
	{	
		for (i = 0; i < iplView->widthStep; i++)
		{
            iValue = (uchar)iplView->imageData[j * iplView->widthStep + i];

			if (iValue >= PIXMAX)
			{
				
                bFound = true;
				iTop = j;
				break;
			}
        }

		if (bFound)
		{
			break;
		}			
    }

	bFound = false;

	cvLine(iplView, cvPoint(iLeft, iStartHeight), cvPoint(iRight, iStartHeight), 
		CV_RGB(255, 255, 255));

	cvLine(iplView, cvPoint(iLeft, iTop), cvPoint(iLeft, iStartHeight), 
		CV_RGB(255, 255, 255));

	cvLine(iplView, cvPoint(iRight, iTop), cvPoint(iRight, iStartHeight), 
		CV_RGB(255, 255, 255));

	cvLine(iplView, cvPoint(iRight, iTop), cvPoint(iLeft, iTop), 
		CV_RGB(255, 255, 255));

	CvRect rectHeadROI;

	rectHeadROI.x = iRight;
	rectHeadROI.y = iStartHeight;
	rectHeadROI.width = iLeft - iRight;
	rectHeadROI.height = iTop - iStartHeight;


	//cvSetErrMode(CV_ErrModeSilent);

	//cvSetImageROI(iplView, cvRect(iLeft, iTop, iLeft - iRight, iTop - iStartHeight));
	cvSetImageROI(iplView, rectHeadROI);
}

void CVDOFXDlg::drawMovementBox(IplImage *iplView, CHead theHead)
{
	cvRectangle(iplView, cvPoint(theHead.rectBox.x, theHead.rectBox.y), 
		cvPoint(theHead.rectBox.width + theHead.rectBox.x,
		theHead.rectBox.height + theHead.rectBox.y), CV_RGB(255, 255, 255));
}

void CVDOFXDlg::OnBnClickedCheckvalue()
{
	// TODO: Add your control notification handler code here
	bEnableThreshold = m_bEnableVale;
	UpdateData(true);
}
