#include "StdAfx.h"
#include ".\extractor.h"

CExtractor::CExtractor(void)
{
}

CExtractor::~CExtractor(void)
{
}
