#pragma once

#include "cv.h"
#include "cxcore.h"


class CExtractor
{
public:
	CExtractor(void);
	~CExtractor(void);


};
