// stdafx.cpp : fichier source incluant simplement les fichiers Include standard
// VDOFX.pch repr�sente l'en-t�te pr�compil�
// stdafx.obj contient les informations de type pr�compil�es

#include "stdafx.h"


