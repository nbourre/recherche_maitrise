#include <cv.h>
#include <highgui.h>
#include <cxcore.h>
#include <cvaux.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string>
#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>  // Lib pour la conversion des strings
#include <direct.h>

#include "projection.h"
#include "head.h"
#include "EyeROI.h"
#include "Eyes.h"

using namespace std;

#define MAXPIX 255

const int projectionSmooth = 15;
const int runningAverageSize = 20;

string csvFile;

// PROTOTYPE
CvRect locateFace(IplImage *img);
IplImage * GetROIImage(IplImage *img);
IplImage * GetSubPixByRect(IplImage *img);
string getExtension(string szFilename);
void addToVector(vector <CvPoint> *vec, CvPoint value);
CvPoint calcAverage(vector <CvPoint> vec);
string createCSV(int line, CvPoint LeftEye, CvPoint RightEye);
string GetCurrentPath();

int main(int argc, char ** argv)
{
	char* winSobel = "Sobel head";
	char* winTemp = "Temp";
	char* winGray = "Gris";
	char* winGradientX = "Gradient X";
	char* winEyesGradient = "Eyes gradient";
	char* winOriginal = "Originale";
	char* winProjection = "Projection";
	char* winEyesProjection = "Eyes projection";

	CvCapture * capture = 0;
	IplImage * imgOriginal = 0;
	IplImage * imgGradientX = 0;
	IplImage * imgGray = 0;
	IplImage * imgProj = 0;
	IplImage * imgProjHorizontal = 0;
	IplImage * imgSmooth = 0;

	CHead head;
	CEyeROI eyeROI;
	CEyes eyes;
	
	CProjection projMain;
	CProjection projY;

	CvSize sz;

	//clock_t start, end;

	//start = clock();

	CvRect rectEyeZone;

	CProjection projEyes;
	IplImage * imgEyes;
	//IplImage * imgProjEyes;

	long nbFrames = 0;
	long frameCount = 0;
	long loopCounter = 0;

	vector <CvPoint> vecEyeZonePos;
	CvPoint ptEyeZoneAvg;
	CvRect rectEyeZonePrevious;
	double eyeZoneThreshold = 0.10;
	bool isInitialized = false;
	int radius = 10;
	

	cout<<"Usage : facedetect filename.[jpg|avi]\r\n";
	cout<<"[q] : Quit\r\n";
	cout<<"[space] : Pause\r\n";	

	
	if (argc > 1)
	{
 		string szFile(_strlwr(argv[1]));
		string szExtension(getExtension(szFile));
		
		if (szExtension == "jpg")
		{
			imgOriginal = cvLoadImage(szFile.c_str());
			nbFrames = 0;
		}
		else if (szExtension == "avi")
		{
			capture = cvCaptureFromFile(szFile.c_str());
			imgOriginal = cvQueryFrame(capture);
			nbFrames = (int)cvGetCaptureProperty(capture, CV_CAP_PROP_FRAME_COUNT);
		}
	}
	else
	{
		printf("Usage : faceDetect picture");
		printf("Press a key to continue...");
		cvWaitKey();
		return 0;
	}
	
	// Construction des objets
	sz = cvSize(imgOriginal->width, imgOriginal->height);
	imgGray = cvCreateImage(sz, 8, 1);
	imgGradientX = cvCreateImage(sz, 8, 1);
	imgSmooth = cvCreateImage(sz, 8, 1);

	// Cr�ation des fen�tres
	//cvNamedWindow(winProjection, CV_WINDOW_AUTOSIZE);
	//cvNamedWindow(winSobel, CV_WINDOW_AUTOSIZE);
	//cvNamedWindow(winGradientX, CV_WINDOW_AUTOSIZE);
	//cvNamedWindow(winEyesProjection, CV_WINDOW_AUTOSIZE);
	cvNamedWindow(winOriginal);

	// Touche appuy�e
	int key = 0;

	// Initialisation du contenu du CSV
	csvFile = createCSV(0, cvPoint(0, 0), cvPoint(0, 0));
	
	for (frameCount = 0;key !='q'; frameCount++)
	{
		if (frameCount > nbFrames - 2)
		{
			cvSetCaptureProperty(capture, CV_CAP_PROP_POS_FRAMES, 0);
			frameCount = 0;
		}
		if (nbFrames > 1)
		{
			imgOriginal = cvQueryFrame(capture);
		}
		////////////////////////////////////////////////////
		// Pr�-traitement

		// Convertion de la couleur vers le niveau de gris
		cvCvtColor(imgOriginal, imgGray, CV_RGB2GRAY);
		
		// Lissage de l'image originale
		cvSmooth(imgGray, imgSmooth, CV_BLUR, 9, 9);	//////  MEMORY LEAK ICI!!

		// Application du Sobel X
		cvSobel(imgSmooth, imgGradientX, 2, 0, 5);

		// Fin pr�=traitement
		////////////////////////////////////////////////////


		//////////////////////////////////
		// D�but de la d�tection de la tete

		//cvSetImageROI(imgGradientX, cvRect(0, 0, imgGradientX->width - 24, imgGradientX->height));
		head.LocateHead(imgGradientX);
		imgProj = head.projection.CreateProjectionImage();

		// Fin de la d�tection de la tete
		//////////////////////////////////


		//////////////////////////////////
		// D�but d�tection zone des yeux

		//cvSetImageROI(imgGradientX, cvRect(head.x, head.y, head.width, head.height));
		//eyeROI.LocateEyes(imgGradientX);
		eyeROI.LocateEyes(imgGradientX, cvRect(0, 0, 0, 0));

		///////////////////////////////////////////
		// Filtre et seuil la position de la ROI
		if (!isInitialized)
		{
			// Calcul la moyenne de la position de la zone des yeux;
			addToVector(&vecEyeZonePos, eyeROI.GetCentre());

			if (loopCounter >= runningAverageSize)
			{
				isInitialized = true;
			}
		}
		else
		{
			double diffEyeZone = abs(eyeROI.GetCentre().y - ptEyeZoneAvg.y) / (double)imgGray->height;

			if (diffEyeZone > eyeZoneThreshold)
			{
				eyeROI.Rec = rectEyeZonePrevious;
			}

			addToVector(&vecEyeZonePos, eyeROI.GetCentre());
		}

		ptEyeZoneAvg = calcAverage(vecEyeZonePos);

		

		rectEyeZone = eyeROI.GetEyeROI();
		//imgProjHorizontal = eyeROI.projection.CreateProjectionImage();

		// Dessiner la r�gion des yeux sur l'image originale
		cvRectangle(imgOriginal, cvPoint(rectEyeZone.x, rectEyeZone.y), 
			cvPoint(rectEyeZone.width + rectEyeZone.x, rectEyeZone.height + rectEyeZone.y), CV_RGB(255, 255, 255));
			
		// fin d�tection zone des yeux
		//////////////////////////////////

		//////////////////////////////////
		// D�but d�tection des yeux
		

		cvSetImageROI(imgSmooth, rectEyeZone);
		imgEyes = GetROIImage(imgSmooth);
		cvResetImageROI(imgSmooth);

		cvResetImageROI(imgGradientX);

		//CEyes eyes(imgEyes);
		eyes.imgEyes = imgEyes;
		eyes.LocateEyes();

		cvReleaseImage(&imgEyes);

		

		// fin d�tection zone des yeux
		//////////////////////////////////
		
		//end = clock();
		//double dif;

		//dif = difftime(end, start) / CLOCKS_PER_SEC;

		//printf("Temp d'execution : %.4f secondes", dif);

		////////////////////////////
		// Dessin

		// Dessiner l'oeil gauche
		CvPoint ptLeftEye;
		ptLeftEye.x = eyes.LeftEye.x + eyeROI.Rec.x;
		ptLeftEye.y = eyes.LeftEye.y + eyeROI.Rec.y;

		cvCircle(imgOriginal, ptLeftEye, radius, CV_RGB(255, 0, 0));

		// Dessiner l'oeil droit
		CvPoint ptRightEye;
		ptRightEye.x = eyes.RightEye.x + eyeROI.Rec.x;
		ptRightEye.y = eyes.RightEye.y + eyeROI.Rec.y;

		cvCircle(imgOriginal, ptRightEye, radius, CV_RGB(255, 0, 0));
			
		// Cr�ation de l'image visuelle de la projection
		//imgProjEyes = eyes.projEyes.CreateProjectionImage();

		//////////////////
		// point milieu
		//cvCircle(imgOriginal, cvPoint((ptLeftEye.x + ptRightEye.x)/2, (ptLeftEye.y + ptRightEye.y)/2), 
		//	radius, CV_RGB(0, 255, 255));

		/////////////////////////////
		// Garder le T-1

		rectEyeZonePrevious = eyeROI.Rec;


		////////////////////////////
		// �criture dans le CSV
		////////////////////////////

		if (loopCounter < nbFrames)
		{
			csvFile.append(createCSV(frameCount + 1, ptLeftEye, ptRightEye));
		}

		////////////////////////////
		// Affichage des images


		//cvShowImage(winGradientX, imgGradientX);
		//cvShowImage(winSobel, imgProj);
		//cvShowImage(winProjection, imgProjHorizontal);
		//cvShowImage(winEyesProjection, imgProjEyes);	
		cvShowImage(winOriginal, imgOriginal);

		key = cvWaitKey(1);

		if (key == ' ')
			key = cvWaitKey();

		
		cvReleaseImage(&imgProj);
		//cvReleaseImage(&imgProjHorizontal);
		//cvReleaseImage(&imgProjEyes);

		++loopCounter;
	}

	// �criture dans le fichier
	time_t curr = time(0);
	struct tm * timeinfo;
	char buff[80];
	timeinfo = localtime (&curr);
	strftime(buff, 80, "%Y%m%d_%H%M%S", timeinfo);

	string szTime(buff);
	string csvFilename = GetCurrentPath() + "\\" + szTime + ".csv";
	ofstream fichier(csvFilename.c_str());
	fichier << csvFile;
	fichier.close();
	
	
	cvReleaseImage(&imgSmooth);
	cvReleaseImage(&imgGray);
	cvReleaseImage(&imgGradientX);
	cvReleaseCapture(&capture);
	
	return 0;
}

/// Fonction qui retourne l'image d'un ROI
IplImage * GetROIImage(IplImage * img)
{
	if (img->roi == NULL)
		return img;

	IplImage * imgOut;

	imgOut = cvCreateImage(cvSize(img->roi->width, img->roi->height), img->depth, img->nChannels);
	cvCopy(img, imgOut);

	return imgOut;
}

string getExtension(string szFilename)
{
	string retExtension;
	size_t dot;

	dot = szFilename.rfind(".");
	retExtension = szFilename.substr(dot + 1);

	return retExtension;

}

void addToVector(vector <CvPoint> *vec, CvPoint value)
{
	int actualSize = vec->size();
	vector <CvPoint>::iterator firstElem;

	if (actualSize >= runningAverageSize)
	{
		firstElem = vec->begin();

		vec->erase(firstElem);
		vec->push_back(value);
	}
	else
	{
		vec->push_back(value);
	}
}

CvPoint calcAverage(vector <CvPoint> vec)
{
	CvPoint avg;
	int i;
	int nbElements = vec.size();

	avg.x = 0;
	avg.y = 0;

	if (nbElements > 0)
	{
		for (i = 0; i < nbElements; i++)
		{
			avg.x += vec.at(i).x;
			avg.y += vec.at(i).y;
		}

		avg.x = avg.x / nbElements;
		avg.y = avg.y / nbElements;
	}
	

	return avg;
}

string createCSV(int line, CvPoint LeftEye, CvPoint RightEye)
{
	string szCSV;
	ostringstream out;

	if (line == 0)
	{
		szCSV = "Frame;leftX;leftY;rightX;rightY\r\n";
	}
	else
	{
		out << line;
		out << ";";
		out << LeftEye.x;
		out << ";";
		out << LeftEye.y;
		out << ";";
		out << RightEye.x;
		out << ";";
		out << RightEye.y;
		out << "\r\n";
		szCSV += out.str();
	}
	
	
	return szCSV;
}


string GetCurrentPath()
{
	char buff[MAX_PATH] = "";
	char *ptr; 

	string szOut;

	ptr = getcwd(buff, MAX_PATH);
	szOut = buff;
	return szOut;	
}