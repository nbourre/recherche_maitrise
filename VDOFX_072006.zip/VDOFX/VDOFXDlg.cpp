// VDOFXDlg.cpp : fichier d'impl�mentation
//

#include "stdafx.h"
#include "VDOFX.h"
#include "VDOFXDlg.h"
#include ".\vdofxdlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// bo�te de dialogue CVDOFXDlg
#define TIMER_ID 1



CVDOFXDlg::CVDOFXDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CVDOFXDlg::IDD, pParent)
	, m_iValue(0)
	, m_bEnableVale(FALSE)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CVDOFXDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_SLIDERVALUE, m_ValueSlider);
	DDX_Control(pDX, IDC_EDITVALUE, m_txtValue);
	DDX_Text(pDX, IDC_EDITVALUE, m_iValue);
	DDX_Check(pDX, IDC_CHECKVALUE, m_bEnableVale);
}

BEGIN_MESSAGE_MAP(CVDOFXDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_WM_HSCROLL()
	ON_BN_CLICKED(IDC_BTNOPEN, OnBnClickedBtnopen)
	ON_WM_CLOSE()
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTONSHOW, OnBnClickedButtonshow)
END_MESSAGE_MAP()


// gestionnaires de messages pour CVDOFXDlg

BOOL CVDOFXDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// D�finir l'ic�ne de cette bo�te de dialogue. L'infrastructure effectue cela automatiquement
	//  lorsque la fen�tre principale de l'application n'est pas une bo�te de dialogue
	SetIcon(m_hIcon, TRUE);			// D�finir une grande ic�ne
	SetIcon(m_hIcon, FALSE);		// D�finir une petite ic�ne

	// TODO : ajoutez ici une initialisation suppl�mentaire
	m_ValueSlider.SetRange(0, 255);
	m_ValueSlider.SetPos(0);
	
	SetTimer(TIMER_ID, 33, NULL);
	bShowVideo = false;

	
	return TRUE;  // retourne TRUE, sauf si vous avez d�fini le focus sur un contr�le
}

// Si vous ajoutez un bouton R�duire � votre bo�te de dialogue, vous devez utiliser le code ci-dessous
//  pour dessiner l'ic�ne. Pour les applications MFC utilisant le mod�le Document/Vue,
//  cela est fait automatiquement par l'infrastructure.

void CVDOFXDlg::OnPaint() 
{
	

	if (IsIconic())
	{
		CPaintDC dc(this); // contexte de p�riph�rique pour la peinture

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Centrer l'ic�ne dans le rectangle client
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Dessiner l'ic�ne
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{

		CDialog::OnPaint();
	}
}

// Le syst�me appelle cette fonction pour obtenir le curseur � afficher lorsque l'utilisateur fait glisser
//  la fen�tre r�duite.
HCURSOR CVDOFXDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CVDOFXDlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	// TODO: Add your message handler code here and/or call default
	m_iValue = m_ValueSlider.GetPos();
	iThreshold = m_iValue;
	UpdateData(false);

	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CVDOFXDlg::OnBnClickedBtnopen()
{
	// TODO: Add your control notification handler code here
	if (!OpenFile())
	{
		AfxMessageBox("Could not open file!");
	}
}

bool CVDOFXDlg::OpenFile()
{
	bool bRet = false;
	CString strExtension;

	char * strFilter = {"AVI file (*.avi)|*.avi|JPEG file (*.jpg)|*.jpg|BMP File (*.bmp)|*.bmp|All files (*.*)|*.*||"};

	CFileDialog FileDlg(true, ".avi", NULL, 0, strFilter);

	if (FileDlg.DoModal() == IDOK)
	{
		bRet = true;
		bShowVideo = false;
		strExtension = FileDlg.GetFileExt();

		if (strExtension.MakeLower() == "avi")
		{
			capture = cvCaptureFromFile(FileDlg.GetFileName());
			NbFrames = (int)cvGetCaptureProperty(capture, CV_CAP_PROP_FRAME_COUNT);
		}
		else
		{			
			iplFrame = cvLoadImage(FileDlg.GetFileName(), 0);
		}

		if (capture == NULL || iplFrame == NULL)
		{
			bRet = false;
		}
	}
	else
	{
		bRet = false;
	}
	
	
	return bRet;
}

void CVDOFXDlg::OnClose()
{
	// TODO: Add your message handler code here and/or call default
	cvDestroyAllWindows();

	CDialog::OnClose();
}

void CVDOFXDlg::OnTimer(UINT nIDEvent)
{
	// TODO: Add your message handler code here and/or call default
	if (bShowVideo)
	{
		if (capture != NULL)
		{
			iplFrame = cvQueryFrame(capture);

			
				cvThreshold(iplFrame, iplFrame, iThreshold, 255, CV_THRESH_TOZERO);

			cvShowImage("Video", iplFrame);

			if (cvGetCaptureProperty(capture, CV_CAP_PROP_POS_FRAMES) >= NbFrames)
			{
				cvSetCaptureProperty(capture, CV_CAP_PROP_POS_FRAMES, 0);  // SetPremierFrame
			}
		}

	}

	CDialog::OnTimer(nIDEvent);
}

void CVDOFXDlg::OnBnClickedButtonshow()
{
	if (!bShowVideo)
	{
		
		cvNamedWindow("Video", CV_WINDOW_AUTOSIZE);
		//cvCreateTrackbar("Slider", "Video", &iThreshold, 255, CVideoEffectDlg::Threshold); 

	}
	else
	{
		cvDestroyWindow("Video");
	}
	
	bShowVideo = !bShowVideo;
	UpdateData(false);
}
