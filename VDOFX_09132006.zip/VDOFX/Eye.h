#pragma once

#include "cv.h"
#include "cxcore.h"

class CEye
{
public:
	CEye(void);
	~CEye(void);

	CvPoint ptCenter;
	int iRadius;	
};
