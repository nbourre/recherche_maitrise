#pragma once

#include "cv.h"
#include "cxcore.h"

class CHead
{
public:
	CHead(void);
	~CHead(void);

	double dTilt;
	double dYaw;
	double dRoll;

	CvPoint ptCenter;

    CvRect rectBox;  // Enclosing box
};
