#pragma once

#include "eye.h"
#include "cv.h"
#include "cxcore.h"
#include "blobresult.h"

class CEyes
{
public:
	CEyes(void);
	~CEyes(void);

	CEye eyeLeft;
	CEye eyeRight;

	IplImage * iplView;

	// Search for eyes in the ROI image.  If eyes are found, the values will be
	// in the eyeLeft and eyeRight properties.
	void SearchEyes(IplImage *iplInput);

private:
	// Look for blobs that could match eyes
	CBlobResult blobs;
	const static int iMinimumArea = 20;
	const static int iMaximumArea = 35;
	void findBlobs(IplImage *iplInput);
};
