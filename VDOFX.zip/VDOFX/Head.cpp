#include "StdAfx.h"
#include ".\head.h"

CHead::CHead(void)
{
}

CHead::~CHead(void)
{
}
