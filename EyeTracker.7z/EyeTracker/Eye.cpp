#include "StdAfx.h"
#include ".\eye.h"

CEye::CEye(void)
{
}

CEye::~CEye(void)
{
}
