//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by EyeTracker.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_EYETRACKER_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDC_btnOpenFile                 1000
#define IDC_txtMsg                      1001
#define IDC_checkGlint                  1003
#define IDC_btnThreshold                1004
#define IDC_txtThresholds               1007
#define IDC_BUTTON2                     1008
#define IDC_btnShowImg                  1008
#define IDC_btnShowVideo                1009
#define IDC_lblIVideoStatus             1010
#define IDC_BUTTON1                     1011
#define IDC_btnFindCircle               1011
#define IDC_txtLeftAvg                  1013
#define IDC_txtRightAvg                 1014
#define IDC_txtRightNbFrames            1015
#define IDC_txtLeftNbFrames             1016
#define IDC_txtLeftAvgY                 1017
#define IDC_txtLeftAvgY2                1018
#define IDC_txtRightAvgY                1018
#define IDC_SLIDER_THRESHOLD            1020
#define IDC_EDIT1                       1021
#define IDC_TXT_TEST                    1021

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1022
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
