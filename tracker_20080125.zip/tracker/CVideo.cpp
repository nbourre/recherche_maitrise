#include "stdafx.h"
#include "CVideo.h"
#include "math.h"

CVideo *vdo = 0;
IplImage *image = 0;
CvPoint pt;
CvRect rect;
int add_remove_pt;
int add_rect;
void on_mouse( int event, int x, int y, int flags, void* param );
CvPoint ptMouse;

//CvPoint *pt;
//int addNbPt;

// Retourne la prochaine image dans le vid�o
IplImage * CVideo::QueryFrame()
{
	return cvQueryFrame(capture);
}

// Retourne la position du prochain frame
int CVideo::GetFramePos()
{
	return (int)cvGetCaptureProperty(capture, CV_CAP_PROP_POS_FRAMES);
}

double CVideo::GetFPS()
{
	return cvGetCaptureProperty(capture, CV_CAP_PROP_FPS);
}

// Remet � z�ro le pointeur de frame
void CVideo::ResetVideo()
{
	cvSetCaptureProperty(capture, CV_CAP_PROP_POS_FRAMES, 0);
}

// Permet de positionner le pointeur sur le frame demand�
void CVideo::SetFramePosition(int Position)
{
	cvSetCaptureProperty(capture, CV_CAP_PROP_POS_FRAMES, Position);
}

// Joue le vid�o en acc�lerer
void CVideo::Play()
{
	cvvNamedWindow("Orignal", CV_WINDOW_AUTOSIZE);

	while(1)
	{
		iplFrame = cvQueryFrame(capture);
		cvvShowImage("Orignal", iplFrame);
		if (cvWaitKey(1)==' ')
			break;
	}

	if (iplFrame != NULL || iplFrame != 0)
	{
		cvReleaseImage(&iplFrame);
	}
}

void CVideo::PlayProcessed()
{
	char *winName = "Original";
	char *win2 = "test";
	char *win3 = "test2";

	cvvNamedWindow(winName, CV_WINDOW_AUTOSIZE);
	cvvNamedWindow(win2, CV_WINDOW_AUTOSIZE);
	cvvNamedWindow(win3, CV_WINDOW_AUTOSIZE);

	CvSize szImg;
	HWND hwnd;
	CvSize filterSize = cvSize(10, 10);
	CvMat *mat;

	IplImage * iplT = 0;
	IplImage * iplT_1 = 0;
	IplImage * iplGray = 0;
	IplImage * iplGraySmall = 0;
	IplImage * iplDifference = 0;
	IplImage * iplMovingAverage = 0;
	IplImage * iplTest = 0;
	IplImage * iplPrevious = 0;
	IplImage * iplThresh = 0;

	CvPoint centre;
	CvSize sizeEll;

	int iFactor = 5;
	int avgX = 0;
	CvPoint pt1, pt2;
	CvPoint2D32f pt3;
	CvPoint2D32f previousFaceCentre;
	double diffX; // servira � calculer le d�placement entre deux positions du visage
	double diffY;
	int radius;
	int nonZero;
	CvRect rectROI;
	

	radius = 35;
	previousFaceCentre.x = 0;
	previousFaceCentre.y = 0;

	szImg = cvGetSize(iplFrame);

	// iplT <-- image redimensionn� � T
	// iplT_1 <-- image � T-1
	// iplDifference <-- difference entre 
	iplT = cvCreateImage(cvSize(iplFrame->width/iFactor, iplFrame->height/iFactor), 8, 1);
	iplT_1 = cvCreateImage(cvSize(iplFrame->width/iFactor, iplFrame->height/iFactor), 8, 1);
	iplDifference = cvCreateImage(cvSize(iplFrame->width/iFactor, iplFrame->height/iFactor), 8, 1);
	iplMovingAverage = cvCreateImage(cvSize(iplFrame->width/iFactor, iplFrame->height/iFactor), 32, 1);
	iplGray = cvCreateImage(cvSize(iplFrame->width, iplFrame->height), 8, 1);
	iplGraySmall = cvCreateImage(cvSize(iplFrame->width/iFactor, iplFrame->height/iFactor), 8, 1);
	iplTest = cvCreateImage(cvSize(iplFrame->width/iFactor, iplFrame->height/iFactor), 8, 1);
	iplPrevious = cvCreateImage(cvSize(iplFrame->width/iFactor, iplFrame->height/iFactor), 8, 1);
	iplThresh = cvCreateImage(cvSize(iplFrame->width/iFactor, iplFrame->height/iFactor), 8, 1);

	CvPoint2D32f *pt;
	CvBox2D32f* box;
	CvRect bndRect = cvRect(0,0,0,0);
	int count;


	bool first = true;

	if (isBusy)
		return;

	isBusy = true;
	while(1)
	{


		if (GetFramePos() >= nbFrames)
			ResetVideo();

		// Capture l'image
		iplFrame = cvQueryFrame(capture);

		// Convertir en 8 bit
		cvCvtColor(iplFrame, iplGray, CV_RGB2GRAY); 
		cvFlip(iplGray);

		// Redimensionne l'image � plus petit pour acqu�rir de la vitesse
		cvResize(iplGray, iplT);


		if (first)
		{
			// Historique
			iplDifference = cvCloneImage(iplT);
			iplT_1 = cvCloneImage(iplT);
			cvConvertScale(iplT, iplMovingAverage, 1, 0);  // ?
			first = false;
		}
		else
		{
			// Moyenne qui se d�place
			cvRunningAvg(iplT, iplMovingAverage, 0.05, NULL);
		}

		cvConvertScale(iplMovingAverage, iplT_1, 1, 0); // ?

		// Difference entre l'image 
		cvAbsDiff(iplT, iplT_1, iplDifference);

		// Copie
		iplGraySmall = cvCloneImage(iplDifference);

		// Image binaire
		cvThreshold(iplGraySmall, iplGraySmall, 75, 255, CV_THRESH_BINARY);

		// Dilater et eroder pour obtenir les blobs
		cvDilate(iplGraySmall, iplGraySmall, 0, 2);
		cvErode(iplGraySmall, iplGraySmall, 0, 2);


		// Pseudo-m�thode pour trouver le centre du visage
		nonZero = cvCountNonZero(iplGraySmall);
		
		if (nonZero > 0 && !first)
		{
			pt3 = getAveragePoint(iplGraySmall);
            	
			// Diff�rence de d�placement en X
			diffX = abs((pt3.x - previousFaceCentre.x) / iplGraySmall->width);
			diffY = abs((pt3.y - previousFaceCentre.y) / iplGraySmall->height);

			if ( diffX < 0.1  && diffY < 0.1)
				cvCircle(iplGraySmall, cvPoint(pt3.x, pt3.y), radius, cvScalar(255, 255, 255));
			else
				cvCircle(iplGraySmall, cvPoint(previousFaceCentre.x, previousFaceCentre.y), 
					radius, cvScalar(255, 255, 255));

			previousFaceCentre = pt3;

		}
		else
		{
			cvCircle(iplGraySmall, cvPoint(previousFaceCentre.x, previousFaceCentre.y), 
				radius, cvScalar(255, 255, 255));
		}
		
		// Afficher le rectangle qui fera office de ROI
		cvRectangle(iplGraySmall, 
			cvPoint(previousFaceCentre.x - radius, previousFaceCentre.y - radius),
			cvPoint(previousFaceCentre.x + radius, previousFaceCentre.y + radius),
			cvScalar(255, 255, 255));

		rectROI.height = 2 * radius;
		rectROI.width = 2 * radius;
		rectROI.x = previousFaceCentre.x;
		rectROI.y = previousFaceCentre.y;

        
		if (!first)
		{
			cvThreshold(iplT, iplTest, 220, 255, CV_THRESH_BINARY);
			cvThreshold(iplPrevious, iplThresh, 200, 255, CV_THRESH_BINARY);
			cvAbsDiff(iplTest, iplThresh, iplPrevious);
			cvShowImage(win3, iplPrevious);
		}
		

		//cvSetImageROI(iplGraySmall, rectROI);

		cvvShowImage(winName, iplT);
		cvShowImage(win2, iplGraySmall);

		//cvResize(iplT, iplGray, CV_INTER_NN);
		

		iplPrevious = cvCloneImage(iplT);
	
		// Emp�che le bogue de fermeture de fen�tre
		hwnd = (HWND)cvGetWindowHandle(winName);
		if (hwnd == NULL)
			break;

		if (cvWaitKey(1)==' ' || BreakPlayback)
			break;			

		cvReleaseImage(&iplGraySmall);
		
		
		

	}
	cvReleaseImage(&iplThresh);
	cvReleaseImage(&iplPrevious);
	cvReleaseImage(&iplTest);
	cvReleaseImage(&iplT_1);
	cvReleaseImage(&iplT);
	cvReleaseImage(&iplGray);
	cvReleaseImage(&iplDifference);
	cvReleaseImage(&iplMovingAverage);
	
	
	isBusy = false;


}

void CVideo::LucasKanade()
{

	if (isBusy)
		return;

	char *winName = "Lucas-Kanade";
	IplImage *grey = 0, *prev_grey = 0, *pyramid = 0, *prev_pyramid = 0, *swap_temp;

	cvvNamedWindow(winName, CV_WINDOW_AUTOSIZE);
	cvSetMouseCallback( winName, on_mouse, 0 );
	

	
	int iPressedChar;
	int i;
	int j;
	int k;
	int win_size = 10;
	HWND hwnd;

	// Lucas-Kanade initialisation
	points[0] = 0;
	points[1] = 0;
	status = 0;
	count = 0;
	count_rect = 0;
	need_to_init = 0;
	night_mode = 0;
	flags = 0;
	add_remove_pt = 0;
	//addNbPt = 0;

	// Indique que l'objet est oqp.
	LKActive = true;
	isBusy = true;

	for (;;)
	{
		iplFrame = 0;
		if (GetFramePos() >= nbFrames)
			ResetVideo();
		iplFrame = cvQueryFrame(capture);

		if (!iplFrame)
			break;

		if (!image)
		{
			//Allouer tous les tampons
			image = cvCreateImage(cvGetSize(iplFrame), 8, 3);
			image->origin = iplFrame->origin;

			grey = cvCreateImage(cvGetSize(iplFrame), 8, 1);
			prev_grey = cvCreateImage(cvGetSize(iplFrame), 8, 1);

			pyramid = cvCreateImage(cvGetSize(iplFrame), 8, 1);
			prev_pyramid = cvCreateImage(cvGetSize(iplFrame), 8, 1);

			// Initialisation des tableau de points
			points[0] = (CvPoint2D32f*)cvAlloc(MAX_COUNT*sizeof(points[0][0]));
			points[1] = (CvPoint2D32f*)cvAlloc(MAX_COUNT*sizeof(points[0][0]));

			for (i = 0; i < T; i++)
			{
				ptTime[i] = (CvPoint2D32f*)cvAlloc(MAX_COUNT * sizeof(ptTime[0][0]));
			}

			// Initialisation des tableau de rect
			rects[0] = (CvRect*)cvAlloc(MAX_COUNT * sizeof(rects[0][0]));
			rects[1] = (CvRect*)cvAlloc(MAX_COUNT * sizeof(rects[0][0]));

			status = (char*)cvAlloc(MAX_COUNT);
			flags = 0;

			//pt = (CvPoint*) cvAlloc(MAX_COUNT * sizeof(pt[0]));
		}

		

		cvCopy( iplFrame, image, 0 );
        cvCvtColor( image, grey, CV_BGR2GRAY );

		if (night_mode)
			cvZero (image);

		if( need_to_init )
        {
            /* automatic initialization */
            IplImage* eig = cvCreateImage( cvGetSize(grey), 32, 1 );
            IplImage* temp = cvCreateImage( cvGetSize(grey), 32, 1 );
            double quality = 0.01;
            double min_distance = 10;

            count = MAX_COUNT;
            cvGoodFeaturesToTrack( grey, eig, temp, points[1], &count,
                                   quality, min_distance, 0, 3, 0, 0.04 );
            cvFindCornerSubPix( grey, points[1], count,
                cvSize(win_size, win_size), cvSize(-1,-1),
                cvTermCriteria(CV_TERMCRIT_ITER|CV_TERMCRIT_EPS,20,0.03));
            cvReleaseImage( &eig );
            cvReleaseImage( &temp );

            add_remove_pt = 0;
        }
        else if( count > 0 )
        {
			// Augmentation du nombre d'it�ration � 30 au lieu de 20 dans les crit�res.
            cvCalcOpticalFlowPyrLK( prev_grey, grey, prev_pyramid, pyramid,
                points[0], points[1], count, cvSize(win_size,win_size), 3, status, 0,
                cvTermCriteria(CV_TERMCRIT_ITER|CV_TERMCRIT_EPS,30,0.03), flags );
            flags |= CV_LKFLOW_PYR_A_READY;

			// Sauvegarde les points dans un vecteur de points temporelle
			savePoints(count);

			// Dessine les points
			for (i = 0; i < T; i++)
			{
				for (j = 0; j < count; j++)
					cvCircle(image, cvPointFrom32f(ptTime[i][j]), 2, CV_RGB(255, i * SPLIT_T, i * SPLIT_T), -1, 8, 0);
			}
			
            

            for( i = k = 0; i < count; i++ )
            {

				if( add_remove_pt )
				{
					
					double dx = pt.x - points[1][i].x;
					double dy = pt.y - points[1][i].y;

					if( dx*dx + dy*dy <= 25 )
					{
						add_remove_pt = 0;
						continue;
					}
				}
	            
				if( !status[i] )
					continue;
	            
				points[1][k++] = points[1][i];
				cvCircle( image, cvPointFrom32f(points[1][i]), 3, CV_RGB(0,255,0), -1, 8,0);			
			
            }

			count = k;


        }

		if( add_remove_pt && count < MAX_COUNT )
        {
            points[1][count++] = cvPointTo32f(pt);
            cvFindCornerSubPix( grey, points[1] + count - 1, 1,
                cvSize(win_size,win_size), cvSize(-1,-1),
                cvTermCriteria(CV_TERMCRIT_ITER|CV_TERMCRIT_EPS,20,0.03));
            add_remove_pt = 0;
        }

		if (add_rect && count_rect < MAX_COUNT)
		{
			cvRectangle (image, cvPoint (rect.x, rect.y), cvPoint(rect.x + rect.width, rect.y + rect.height), 
				cvScalar(255, 0, 0), 1);
			add_rect = 0;
		}

        CV_SWAP( prev_grey, grey, swap_temp );
        CV_SWAP( prev_pyramid, pyramid, swap_temp );
        CV_SWAP( points[0], points[1], swap_points );
        need_to_init = 0;

		cvvShowImage(winName, image);

		// Emp�che le bogue de fermeture de fen�tre
		hwnd = (HWND)cvGetWindowHandle(winName);
		if (hwnd == NULL)
			break;

		// V�rifie si une touche a �t� appuy�e
		iPressedChar = cvWaitKey(10);
		if ((char)iPressedChar == 27)
		{
			break;
		}

		switch( (char) iPressedChar)
        {
        case 'r':
            need_to_init = 1;
            break;
        case 'c':
            count = 0;
            break;
        case 'n':
            night_mode ^= 1;
            break;
		case ' ':
			cvWaitKey();
			break;
        default:
            ;
        }
	}

	LKActive = false;
	isBusy = false;

	cvvDestroyWindow(winName);
}

void on_mouse( int event, int x, int y, int flags, void* param )
{
    if( !image )
        return;

    if( image->origin )
        y = image->height - y;

	switch (event)
	{
		case CV_EVENT_LBUTTONDOWN:
			//Bouton gauche avec Ctrl
			if (flags & CV_EVENT_FLAG_CTRLKEY)
			{
				//AfxMessageBox("CTRL + Left button");
				rect = cvRect(x, y, 125, 75);
				add_rect = 1;
			}
			else
			{
				pt = cvPoint(x, y);
				add_remove_pt = 1;
			}
			break;

		case CV_EVENT_MOUSEMOVE:
			ptMouse = cvPoint(x, y);
			break;
	}
}

// Retourne la liste de points qui ont �t� cliquer dans la m�thode Lucas-Kanade
CString CVideo::GetPointList()
{
	if (count == NULL || count == 0)
		return NULL;


	CString szRet = "";
	CString szPoint = "";
	CString szX = "";
	CString szY = "";

	for (int i = 0; i < count; i++)
	{
		szX = "";
		szY = "";

		//Conversion du float en CString
		szX.Format("%3.f", points[1][i].x);
		szY.Format("%3.f", points[1][i].y);
		
		szPoint.Format ("Points %d --> x=%s, y=%s\r\n", i, szX, szY);
		szRet = szRet + szPoint;
	}

	return szRet;
}

// Retourne vrai si LK est en fonction
bool CVideo::GetLKStatus()
{
	if (LKActive != NULL)
		return LKActive;
	else
		return NULL;
}

// Retourne vrai si un affichage vid�o est en fonction
bool CVideo::GetStatus()
{
	if (isBusy != NULL)
		return isBusy;
	else
		return NULL;
}

// Retourne la position de la souris
CvPoint CVideo::GetMousePos()
{
	return ptMouse;
}

// Copier les valeurs dans le vecteur de temps pass�
void CVideo::savePoints(int nbPoints)
{

	// Copie T vers T + 1
	for (int i = T - 2; i >= 0; i--)
	{
		for (int j = 0; j < nbPoints; j++)
		{
			ptTime[i + 1][j] = ptTime[i][j];
		}
	}


	for (i = 0; i < nbPoints; i++)
	{
		ptTime[0][i] = points[1][i];
	}

}

// Pixellisation de l'image en r�gion brute.  En test.
IplImage * CVideo::regionMethod(IplImage *img, int filterSize)
{
	IplImage *imgRet;
	CvRect rROI;

	rROI.height = filterSize;
	rROI.width = filterSize;

	imgRet = 0;
	imgRet = cvCreateImage(cvGetSize(img), 8, 1);

	int i, j;
	int iMean;

	for (j = 0; j < img->height; j += filterSize)
	{
		for (i = 0; i < img->width; i += filterSize)
		{
			

			rROI.x = i;
			rROI.y = j;

			cvSetImageROI(img, rROI);

			// Moyenne du ROI
			iMean = (int)cvMean(img);

			// Dessine le rectangle
			cvRectangle (imgRet, cvPoint(rROI.x, rROI.y), cvPoint(rROI.x + rROI.width, rROI.y + rROI.height), 
				cvScalar(iMean), CV_FILLED);

			if ((i + rROI.width) > img->width - 1)
			{
				rROI.width = img->width - 1 - i; // Derni�re colonne
			}

			cvResetImageROI(img);
		}

		rROI.width = filterSize;  // R�initialise la grandeur du rRoi

		if ((j + rROI.height) > img->height - 1)
		{
			rROI.height = img->height - 1 - j; // derni�re rang�e
		}
	}

	cvFlip(imgRet);

	return imgRet;
}

CvPoint2D32f * CVideo::getPointArray(IplImage *img)
{
	
	CvPoint2D32f *pt;
	int nbPts = 0;
	int cpt = 0;
	uchar data;

	nbPts = cvCountNonZero(img);

	pt = new CvPoint2D32f[nbPts];

	for (int j = 0; j < img->height; j++)
	{
		for (int i = 0; i < img->width; i++)
		{
			data = (uchar)img->imageData[i * img->height + j];

			if (data > 0)
			{
				pt[cpt].x = i;
				pt[cpt++].y = j;
			}
		}

	}

	return pt;
}


// Retourne la position moyenne des points
// Probl�me probl�me, ne semble pas retourner la bonne valeur
CvPoint2D32f CVideo::getAveragePoint(IplImage *img)
{
	CvPoint2D32f pt;
	int nbPoints = cvCountNonZero(img);
	long sumX = 0;
	long sumY = 0;

	for (int j = 0; j < img->height; j++)
	{
		for (int i = 0; i < img->widthStep; i++)
		{
			
			if ((uchar)img->imageData[j * img->width + i] > 200)
			{
				sumX += i;
				sumY += j;
			}
		}
	}

	pt.x = sumX / nbPoints;
	pt.y = sumY / nbPoints;

	return pt;
}

