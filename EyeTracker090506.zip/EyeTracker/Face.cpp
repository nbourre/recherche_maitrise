#include "StdAfx.h"
#include ".\face.h"

CFace::CFace(void)
{
}

CFace::~CFace(void)
{
}
