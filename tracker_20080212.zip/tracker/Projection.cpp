#include "StdAfx.h"
#include "Projection.h"

CProjection::CProjection(void)
{
	isInitialized = false;
}

CProjection::~CProjection(void)
{
	isInitialized = false;
}

CProjection::CProjection(IplImage *img)
{
	isInitialized = false;
	CreateHorizontalProjection(img);
}

/// Retourne l'image repr�sentant la projection
IplImage * CProjection::CreateProjectionImage()
{
	IplImage * imgRet = 0;

	int width = 320;
	int height = Count;

	int i, j;
	double ratioWidth;
	double maxUpperRange, maxLowerRange;

	if (MaxValue > 0)
	{

		imgRet = cvCreateImage(cvSize(width, height), 8, 1);
		cvZero(imgRet);
		ratioWidth = width / MaxValue;
		maxUpperRange = MaxPosition + 0.05 * height;
		maxLowerRange = MaxPosition - 0.05 * height;
		

		for (j = 0; j < height; j++)
		{
			if (j >= maxLowerRange && j <= maxUpperRange)
				cvLine(imgRet, cvPoint(0, j), cvPoint(ratioWidth * Values[j], j), CV_RGB(255, 255, 255));
			else
				cvLine(imgRet, cvPoint(0, j), cvPoint(ratioWidth * Values[j], j), CV_RGB(127, 127, 127));
		}

	}
	return imgRet;
}

/// M�thode permettant de cr�er une sommation des niveaux de gris
/// a l'horizontale d'une image
void CProjection::CreateHorizontalProjection(IplImage *img)
{
	int i, j;

	int xStart, yStart;
	int xEnd, yEnd;
	int hSum;
	int nbElements;

	int maxValue = 0;
	int maxPos = 0;
	
	if (img->roi != NULL)
	{
		xStart = img->roi->xOffset;
		yStart = img->roi->yOffset;

		xEnd = img->roi->width + xStart;
		yEnd = img->roi->height + yStart;
		nbElements = img->roi->height - yStart;		
	}
	else
	{
		xStart = 0;
		yStart = 0;
		xEnd = img->width;
		yEnd = img->height;
		nbElements = img->height;
	}

	if (!isInitialized)
	{
		setSize(nbElements);
		isInitialized = true;
	}


	for (j = yStart; j < yEnd; j++)
	{
		hSum = 0;
		for (i = xStart; i < xEnd; i++)
		{
			hSum += (int)img->imageData[j * img->width + i];
		}

		if (hSum > maxValue)
		{
			maxValue = hSum;
			maxPos = j - yStart;
		}
		Values[j - yStart] = hSum;
	}

	MaxValue = maxValue;
	MaxPosition = maxPos;
	Count = nbElements;
	isHorizontal = true;
}

void CProjection::CreateVerticalProjection(IplImage *img)
{
	int i, j;

	int xStart, yStart;
	int xEnd, yEnd;
	int vSum;
	int nbElements;

	int maxValue = 0;
	int maxPos = 0;
	
	if (img->roi != NULL)
	{
		xStart = img->roi->xOffset;
		yStart = img->roi->yOffset;

		xEnd = img->roi->width + xStart;
		yEnd = img->roi->height + yStart;

		nbElements = img->roi->width - xStart;		
	}
	else
	{
		xStart = 0;
		yStart = 0;
		xEnd = img->width;
		yEnd = img->height;

		nbElements = img->width;
	}

	if (!isInitialized)
	{
		setSize(nbElements);
		isInitialized = true;
	}


	for (i = xStart; i < xEnd; i++)
	{
		vSum = 0;
		for (j = yStart; j < yEnd; j++)
		{
			vSum += (int)img->imageData[j * img->width + i];
		}

		if (vSum > maxValue)
		{
			maxValue = vSum;
			maxPos = i - xStart;
		}
		Values[i - xStart] = vSum;
	}

	MaxValue = maxValue;
	MaxPosition = maxPos;
	Count = nbElements;
	isHorizontal = false;
}



void CProjection::setSize(int size)
{
	Values = new int[size];
}

void CProjection::Reset()
{
	if (isInitialized)
	{
		delete [] Values;
		isHorizontal = 0;
	}
}