#pragma once

#include "cv.h"

class CProjection
{
public:
	CProjection(void);
	~CProjection(void);

	CProjection(IplImage *img);

	IplImage * CreateProjectionImage();
	void CreateHorizontalProjection(IplImage *img);
	void CreateVerticalProjection(IplImage *img);
	void Reset();  // Remet � z�ro les valeurs

	int * Values;
	int Count;
	double MaxValue;
	int MaxPosition;

private:
	bool isInitialized;		// Est initilialis�
	void setSize(int size);	// Dimension de la projection
	bool isHorizontal;		// Type de projection
};


